#ifndef GLM_FORCE_CXX03
#	define GLM_FORCE_CXX03
#endif

#include <glm/glm.hpp>
#include <glm/ext.hpp>

int main()
{
	int Error = 0;

	return Error;
}

